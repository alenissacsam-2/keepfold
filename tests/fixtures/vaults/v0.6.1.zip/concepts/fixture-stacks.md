---
id: "fixture-stacks"
title: "Fixture stacks"
parent: "[[fixture-data-structures.linear]]"
domain: "fixture-data-structures"
aliases: []
requires: []
mistakes: []
cortex_status: "learning"
cortex_next: "2026-12-02"
---
# Fixture stacks

## Notes
