---
id: "fixture-data-structures.linear"
title: "Linear"
kind: "area"
domain: "fixture-data-structures"
parent: "[[fixture-data-structures]]"
---
# Linear

## Notes
