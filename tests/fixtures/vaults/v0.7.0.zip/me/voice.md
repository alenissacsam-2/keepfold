---
summary: How I write
---

# How I write

Style rules per audience: one `## <audience>` section each (professor, friend, people/<slug>), e.g. `- Formal greeting, at most 5 sentences, signs "Regards"`.

## Everyone

## Past

## Not me
