---
summary: Who I am
---

# Who I am

## Background

## Current focus

## Past

## Not me
