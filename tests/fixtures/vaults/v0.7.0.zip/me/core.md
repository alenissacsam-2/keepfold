---
summary: Always about me
---

# Always about me

Pinned: every chat starts with these lines, word for word, ahead of everything else (500 characters in all; a line that does not fit is left out whole). Only lines you write or confirm count.

## Core

## Past

## Not me
