---
summary: How I tick
---

# How I tick

One line per entry: `- <trait> — seen: <evidence> (confirmed YYYY-MM-DD)`.

## Values

## How I think

## How I decide

## Strengths

## Growth edges

## Communication

## Energy and routines

## Past

## Not me
