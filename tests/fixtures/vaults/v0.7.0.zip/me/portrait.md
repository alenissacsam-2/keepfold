---
summary: My monthly portrait
---

# My monthly portrait

One `## YYYY-MM` section per month, drafted by the assistant and approved by me.
