---
summary: My setup
---

# My setup

## Hardware

## Software

## Past

## Not me
