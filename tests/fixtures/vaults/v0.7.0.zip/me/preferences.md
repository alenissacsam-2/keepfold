---
summary: My preferences
---

# My preferences

## Coding

## Communication

## Learning

## Workflow

## Environment

## Career

## Personal
- Synthetic fixture: show a short worked example before the rule. (confirmed 2026-11-28) ^c-eqdpl

## Past

## Not me
