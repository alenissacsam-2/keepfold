---
summary: How to teach me
---

# How to teach me

Ask before you teach. Keep answers short.

## Core rules

- Ask a closed-book question before explaining.

## Domain overrides

<!-- Add `### <domain id>` subsections (e.g. `### math`); only matching ones load. -->
