---
id: "fixture-note-on-stacks"
title: "Fixture note on stacks"
kind: "note"
tags: []
related: []
summary: "A stack is last in, first out."
---
# Fixture note on stacks

## Notes
