---
id: "fixture-data-structures"
title: "Fixture data structures"
kind: "domain"
aliases: []
---
# Fixture data structures

## Notes
